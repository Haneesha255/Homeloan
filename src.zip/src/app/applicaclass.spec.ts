import { Applicaclass } from './applicaclass';

describe('Applicaclass', () => {
  it('should create an instance', () => {
    expect(new Applicaclass()).toBeTruthy();
  });
});
