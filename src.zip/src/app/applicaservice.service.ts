import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Applicaclass } from './applicaclass';

@Injectable({
  providedIn: 'root'
})
export class ApplicaserviceService {

  constructor(private myhttp:HttpClient) { }
  restUrl:string="http://localhost:8191/rest/api/";
  getAllRegiform()
  {
    return this.myhttp.get(this.restUrl+"/app")

  }
  addRegiform(ab:Applicaclass)
  {
    return this.myhttp.post(this.restUrl+"/app",ab)
  }
 
}