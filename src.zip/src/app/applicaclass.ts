export class Applicaclass {

	
		 propertyLoc:string |undefined;
		 propertyName:string |undefined;
		 propertyEstimatedAmount: number |undefined;		
		 typeOfEmployment:string |undefined;		
		 retirementAge: number |undefined;
		 orgType:string |undefined;		
	     income:number |undefined;
		
}
