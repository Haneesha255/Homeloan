import { Custform } from './custform';

describe('Custform', () => {
  it('should create an instance', () => {
    expect(new Custform()).toBeTruthy();
  });
});
